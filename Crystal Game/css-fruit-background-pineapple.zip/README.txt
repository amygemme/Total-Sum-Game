A Pen created at CodePen.io. You can find this one at http://codepen.io/AngelaVelasquez/pen/yVEOpY.

 This idea came to me this year. I really love Lea Verou's  CSS3 patterns gallery, so I decided create my own CSS3 background gallery to practice my CSS skills and there's no better topic than fruits for patterns :D.

I hope codepen enjoy this backgrounds. 